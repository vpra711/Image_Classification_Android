package com.example.imageclassification;

import static com.example.imageclassification.MainActivity.resultList;
import android.os.Bundle;
import android.widget.TextView;
import java.util.List;

public class ScrollView extends ClassAndMethods
{
    TextView fullresultTV;
    List<Fruit> resultList1 = resultList;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        getSupportActionBar().setTitle(R.string.result);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scrollview);
        fullresultTV = findViewById(R.id.fullresulttv2x);
        StringBuilder fullresult = new StringBuilder("\n");

        for (int i = 0; i < 1000; i++)
            fullresult.append(resultList1.get(i).name).append(" | ").append(resultList1.get(i).probability).append("\n\n");

        fullresultTV.setText(fullresult.toString());
    }
}