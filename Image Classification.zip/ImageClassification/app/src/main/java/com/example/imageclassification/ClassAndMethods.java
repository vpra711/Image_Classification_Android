package com.example.imageclassification;

import android.content.Context;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import java.util.Comparator;

public class ClassAndMethods extends AppCompatActivity
{
    public void maketoast(String msg)
    { Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show(); }

    public void openThemeDialog(Context c)
    {
        String[] themes={"System Default","Light Theme","Dark Theme"};
        AlertDialog.Builder builder=new AlertDialog.Builder(c);
        builder.setTitle("Select Theme");
        builder.setSingleChoiceItems(themes, 0, (dialog, index) ->
        {
            if(themes[index].equals("System Default"))
            {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.getDefaultNightMode());
                dialog.dismiss();
            }
            else if(themes[index].equals("Light Theme"))
            {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                dialog.dismiss();
            }
            else if(themes[index].equals("Dark Theme"))
            {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                dialog.dismiss();
            }
        });
        builder.show();
    }
}

class Fruit
{
    String name;
    float probability;

    Fruit(String name,float probability)
    {
        this.name=name;
        this.probability=probability;
    }
}

class CompareObj implements Comparator<Fruit>
{
    @Override
    public int compare(Fruit f1,Fruit f2)
    {
        if(f1.probability > f2.probability)
            return -1;
        else if(f1.probability == f2.probability)
            return 0;
        return 1;
    }
}